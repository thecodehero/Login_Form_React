export default function Button({ value, buttonStyle, onClick }) {
  return (
    <button className={buttonStyle} onClick={onClick}>
      {value}
    </button>
  );
}
