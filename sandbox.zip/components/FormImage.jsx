import "../src/styles.css";
import pattern from "../img/imagereactchallenge.png";

//form image component
export default function FormImage() {
  return <img className="FormImage" src={pattern} alt="pattern" />;
}
