import "../src/styles.css";

export default function HyperLink({ text, href }) {
  return (
    <a href={href} className="hyperlink">
      {text}
    </a>
  );
}
