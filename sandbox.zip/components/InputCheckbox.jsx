import HyperLink from "./HyperLink.jsx";

export default function ({ container, checkmark }) {
  return (
    <div>
      <label className="container">
        I agree to the <HyperLink href="#" text="Terms" /> and{" "}
        <HyperLink href="#" text="Privacy Policy" />
        <input type="checkbox" />
        <span class="checkmark"></span>
      </label>
    </div>
  );
}
