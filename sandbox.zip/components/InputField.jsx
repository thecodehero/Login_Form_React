export default function InputField({
  type,
  name,
  value,
  placeholder,
  className,
}) {
  return (
    <input
      type={type}
      name={name}
      value={value}
      placeholder={placeholder}
      className={className}
    />
  );
}
