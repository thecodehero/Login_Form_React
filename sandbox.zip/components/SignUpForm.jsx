import "../src/styles.css";
import InputField from "./InputField.jsx";
import InputCheckbox from "./InputCheckbox.jsx";
import Button from "./Button.jsx";
import SocialIcon from "./Social.jsx";

//sign up form component
export default function SignUpForm() {
  return (
    <div className="SignUpForm">
      <h2>Create Account</h2>
      <div>
        <SocialIcon />
      </div>
      <div className="subText">or use your email for registration</div>
      <InputField className="textInput" name="name" placeholder="Name" />
      <br />
      <InputField className="textInput" name="email" placeholder="Email" />
      <br />
      <InputField
        className="textInput"
        type="text"
        name="password"
        placeholder="Password"
      />
      <br />
      <InputCheckbox container="container" checkmark="checkmark" />
      <br />
      <div className="formButtons">
        <Button value="Sign Up" buttonStyle="button buttonSignUp" />
        <Button value="Sign In" buttonStyle="button buttonSignIn" />
      </div>
    </div>
  );
}
