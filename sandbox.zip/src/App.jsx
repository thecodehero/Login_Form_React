import SignUpForm from "../components/SignUpForm.jsx";
import FormImage from "../components/FormImage.jsx";

import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <div className="AppContent">
        <SignUpForm />
        <FormImage />
      </div>
    </div>
  );
}
